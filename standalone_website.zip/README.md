# 早知道｜可直接開啟的獨立版

## 開啟方式

解壓縮後，可在 VS Code 開啟資料夾並直接雙擊最外層 `index.html`；也可使用 VS Code Live Server 從同一個檔案啟動。不要直接開啟 `source/client/index.html`，那是用來重建網站的 Vite 原始碼入口。

主網頁檔名是 **`index.html`**，文件使用 **UTF-8** 編碼。CSS 與 JavaScript 已內嵌在同一個 HTML 中，不需另外載入 module、建置 bundle 或 Manus API。圖片放在 `images/` 資料夾，使用相對路徑；檔名範例：`./images/zaozhidao-mark.webp`（品牌圖示）、`./images/nccu-breakfast-offline.svg`（離線座標圖）。

## 離線功能與地圖說明

首頁、店家資料、四個主要頁面及互動遊戲均封存在本機檔案；載入時不會呼叫 Manus API 或 Manus Storage，也不需登入、資料庫或網路。Google My Maps／Google Maps 按鈕是使用者點擊後才開啟的外連，因此需要網路。

離線版地圖沿用你提供的 My Maps KML 中 **23 個圖釘座標**，以本機 SVG 座標圖呈現並連到店家詳情。這是位置座標圖，不含 Google 街道底圖、圖磚或路線導航。店家名單另有 `BigBurger 比飽嗝大漢堡早午餐` 和 `三三活力早餐店` 不在原始 KML 中，所以不猜測座標。Google 官方說明 My Maps 可匯出 KML/KMZ；Google 地圖圖磚則有離線快取限制，因此封存包不包含 Google 底圖：[My Maps 匯出說明](https://support.google.com/mymaps/answer/3109452?hl=zh-Hant)；[Google Maps Platform Map Tiles 政策](https://developers.google.com/maps/documentation/tile/policies)。

## 原始碼與重建

`source/` 內含 React／TypeScript／CSS 原始碼、25 家店家 JSON、My Maps KML、離線圖產生器和歷史指令紀錄。原始 starter 隨附的伺服器範本也保留作參考，但早餐網站的靜態功能不會啟動或呼叫它。

如需修改原始碼並重建（安裝依賴需要網路），在 `source/` 目錄執行：

```sh
pnpm install --frozen-lockfile
pnpm build:static
python3 tools/package_standalone.py ../
```

最後一個指令會更新最外層 `index.html` 與 `images/`。網站直接開啟不需要安裝任何套件。
