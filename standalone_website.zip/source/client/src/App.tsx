import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Router as WouterRouter, Switch } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import ErrorBoundary from "./components/ErrorBoundary";
import { SiteFooter, SiteHeader } from "./components/SiteHeader";
import { ThemeProvider } from "./contexts/ThemeContext";
import FindBreakfast from "./pages/FindBreakfast";
import Home from "./pages/Home";
import Nearby from "./pages/Nearby";
import ShopDetail from "./pages/ShopDetail";

function AppRoutes() {
  return (
    <div className="site-shell">
      <SiteHeader />
      <main className="site-main">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/find" component={FindBreakfast} />
          <Route path="/nearby" component={Nearby} />
          <Route path="/shops/:id" component={ShopDetail} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <SiteFooter />
    </div>
  );
}

function App() {
  return (
    <WouterRouter hook={useHashLocation}>
      <ErrorBoundary>
        <ThemeProvider defaultTheme="light">
          <TooltipProvider>
            <Toaster />
            <AppRoutes />
          </TooltipProvider>
        </ThemeProvider>
      </ErrorBoundary>
    </WouterRouter>
  );
}

export default App;
