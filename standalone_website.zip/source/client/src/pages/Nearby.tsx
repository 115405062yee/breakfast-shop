import { ArrowRight, ExternalLink, MapPin, Navigation } from "lucide-react";
import { Link } from "wouter";
import { breakfastShops, getDisplayAddress, getGoogleMapsUrlForShop, getShopTypeLabels } from "@/lib/breakfast-data";

export default function Nearby() {
  const nearbyShops = breakfastShops;

  return (
    <div className="page-container content-page nearby-page">
      <div className="page-heading nearby-heading">
        <span className="section-kicker">CLOSE TO YOUR MORNING</span>
        <h1>店家<span>總覽</span></h1>
        <p>在清單框內滑動瀏覽政大周邊早餐店與便利商店，點選店家查看詳細資訊與地圖。</p>
        <div className="location-pill"><MapPin size={15} fill="currentColor" /> 政大周邊 <span>Excel 測試名單</span></div>
      </div>

      <div className="nearby-toolbar">
        <div><strong>早餐店清單</strong><span>共 {nearbyShops.length} 間測試店家</span></div>
        <span className="sort-note">依 Excel 名單順序</span>
      </div>
      <div className="nearby-list" role="region" aria-label="可捲動店家清單" tabIndex={0}>
        {nearbyShops.map((shop, index) => {
          const shopLabels = getShopTypeLabels(shop);
          return (
            <article className="nearby-row" key={shop.id}>
              <span className="nearby-index">{String(index + 1).padStart(2, "0")}</span>
              <div className="nearby-row-icon" aria-hidden="true">{shop.emoji}</div>
              <div className="nearby-row-main">
                <span className="demo-tag">{shop.featuredLabel}</span>
                <h2>{shop.name}</h2>
                <p>{getDisplayAddress(shop)}</p>
                <div className="nearby-row-tags">
                  {shopLabels.length > 0
                    ? shopLabels.slice(0, 3).map((category) => <span key={category}>{category}</span>)
                    : <span>餐點資料待補</span>}
                </div>
              </div>
              <div className="nearby-row-meta">
                {shop.openingHours && <span>營業時間：{shop.openingHours}</span>}
                {shop.openingDays && <span>{shop.openingDays}</span>}
                <a className="nearby-map-link" href={getGoogleMapsUrlForShop(shop)} target="_blank" rel="noopener noreferrer">Google 地圖詳細查詢 <ExternalLink size={12} /></a>
              </div>
              <Link className="nearby-row-link" href={`/shops/${shop.id}`} aria-label={`查看${shop.name}資料`}><ArrowRight size={19} /></Link>
            </article>
          );
        })}
      </div>
      <div className="nearby-footnote"><Navigation size={17} /><p>此為 Excel 測試名單，並不代表店家目前營業狀態。未提供的步行距離與營業資訊不推估；請使用每家店的 Google 地圖連結查詢最新路線與公告。</p></div>
    </div>
  );
}
