import { ArrowRight, Coins, Dices, ExternalLink, Fish, MapPin, RefreshCw, RotateCw, Sparkles } from "lucide-react";
import { useEffect, useRef, useState, type KeyboardEvent as ReactKeyboardEvent, type PointerEvent as ReactPointerEvent } from "react";
import { Link, useLocation } from "wouter";
import { breakfastShops, getDisplayAddress, getGoogleMapsUrlForShop, type BreakfastShop } from "@/lib/breakfast-data";
import OfflineBreakfastMap from "@/components/OfflineBreakfastMap";

const googleMapsSearchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("早餐店 國立政治大學 台北市文山區")}`;
const googleMyMapsEmbedUrl = "https://www.google.com/maps/d/embed?mid=1lSbMF8DcdnpdkM4px_zbnMP5SdpaJ_s&ehbc=2E312F&hl=zh-TW";
const FORTUNE_SHAKES_REQUIRED = 4;
const FISH_PULLS_REQUIRED = 4;
const FISHING_SCENE_COUNT = 8;
const CAPSULE_SHELLS = [
  { name: "珊瑚紅", color: "#ff4967" },
  { name: "湖水綠", color: "#00bca8" },
  { name: "陽光黃", color: "#ffc928" },
  { name: "海水藍", color: "#347cff" },
  { name: "莓果粉", color: "#f04eb5" },
  { name: "葡萄紫", color: "#8d5be8" },
] as const;

type RandomMode = "capsule" | "fortune" | "fishing";
type GamePhase = "ready" | "capsule-turning" | "capsule-rolling" | "capsule-dispensing" | "fortune-shaking" | "fortune-falling" | "fishing-waiting" | "fishing-bite" | "fishing-catching" | "fishing-landed";
type FortuneGesture = { active: boolean; lastX: number; direction: number; segmentDistance: number; reversals: number };
type CoinGesture = { active: boolean; startX: number; startY: number; originX: number; originY: number; baseLeft: number; baseTop: number };

function getDailyPicks(): BreakfastShop[] {
  if (breakfastShops.length === 0) return [];
  const today = new Date();
  const daySeed = today.getFullYear() * 372 + (today.getMonth() + 1) * 31 + today.getDate();
  const startIndex = daySeed % breakfastShops.length;
  return Array.from({ length: Math.min(3, breakfastShops.length) }, (_, index) =>
    breakfastShops[(startIndex + index) % breakfastShops.length],
  ).filter((shop): shop is BreakfastShop => Boolean(shop));
}

function getMenuPreview(shop: BreakfastShop): string {
  if (shop.businessCategory === "便利商店") return "便利商店・商品與售價不特別整理";
  return shop.signature?.name ?? shop.popularItems[0]?.name ?? "餐點資料待補";
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [randomMode, setRandomMode] = useState<RandomMode>("capsule");
  const [randomShop, setRandomShop] = useState<BreakfastShop | null>(null);
  const [capsuleShellIndex, setCapsuleShellIndex] = useState(0);
  const [phase, setPhaseState] = useState<GamePhase>("ready");
  const [coinInserted, setCoinInserted] = useState(false);
  const [coinOffset, setCoinOffsetState] = useState({ x: 0, y: 0 });
  const [isCoinDragging, setIsCoinDragging] = useState(false);
  const [fortuneShakeCount, setFortuneShakeCount] = useState(0);
  const [fishingPullCount, setFishingPullCount] = useState(0);
  const [fishingSceneSpot, setFishingSceneSpot] = useState(-1);
  const [fishingClickPulse, setFishingClickPulse] = useState(0);
  const phaseRef = useRef<GamePhase>("ready");
  const drawTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingWinnerRef = useRef<BreakfastShop | null>(null);
  const coinOffsetRef = useRef({ x: 0, y: 0 });
  const coinGestureRef = useRef<CoinGesture>({ active: false, startX: 0, startY: 0, originX: 0, originY: 0, baseLeft: 0, baseTop: 0 });
  const capsuleGameRef = useRef<HTMLDivElement | null>(null);
  const capsuleSlotRef = useRef<HTMLElement | null>(null);
  const lastCapsuleShellIndexRef = useRef(-1);
  const fortuneGestureRef = useRef<FortuneGesture>({ active: false, lastX: 0, direction: 0, segmentDistance: 0, reversals: 0 });
  const fishingPullCountRef = useRef(0);
  const dailyPicks = getDailyPicks();
  const convenienceStoreCount = breakfastShops.filter((shop) => shop.businessCategory === "便利商店").length;
  const isBusy = phase !== "ready";
  const fishingPulseClass = fishingClickPulse > 0 ? `pull-pulse-${fishingClickPulse % 3}` : "";

  const setPhase = (next: GamePhase) => {
    phaseRef.current = next;
    setPhaseState(next);
  };

  const scheduleDraw = (callback: () => void, delay: number) => {
    if (drawTimerRef.current !== null) clearTimeout(drawTimerRef.current);
    drawTimerRef.current = setTimeout(() => {
      drawTimerRef.current = null;
      callback();
    }, delay);
  };

  const updateCoinOffset = (offset: { x: number; y: number }) => {
    coinOffsetRef.current = offset;
    setCoinOffsetState(offset);
  };

  const snapCoinToSlot = (coin: HTMLButtonElement) => {
    const slot = capsuleSlotRef.current;
    if (!slot) return;
    const slotBounds = slot.getBoundingClientRect();
    const coinBounds = coin.getBoundingClientRect();
    const baseLeft = coinBounds.left - coinOffsetRef.current.x;
    const baseTop = coinBounds.top - coinOffsetRef.current.y;
    updateCoinOffset({
      x: slotBounds.left + slotBounds.width / 2 - (baseLeft + coinBounds.width / 2),
      y: slotBounds.top + slotBounds.height / 2 - (baseTop + coinBounds.height / 2),
    });
    setCoinInserted(true);
  };

  const chooseWinner = () => {
    const candidates = breakfastShops.filter((shop) => shop.id !== randomShop?.id);
    const pool = candidates.length > 0 ? candidates : breakfastShops;
    return pool[Math.floor(Math.random() * pool.length)] ?? null;
  };

  const beginRound = (initialPhase: GamePhase) => {
    if (phaseRef.current !== "ready" || breakfastShops.length === 0) return false;
    const winner = chooseWinner();
    if (!winner) return false;
    pendingWinnerRef.current = winner;
    setRandomShop(null);
    setPhase(initialPhase);
    return true;
  };

  const revealWinner = () => {
    if (pendingWinnerRef.current) setRandomShop(pendingWinnerRef.current);
    pendingWinnerRef.current = null;
    if (randomMode === "capsule") {
      setCoinInserted(false);
      setIsCoinDragging(false);
      coinGestureRef.current.active = false;
      updateCoinOffset({ x: 0, y: 0 });
    }
    setPhase("ready");
  };

  const startCapsuleRound = () => {
    if (!coinInserted || !beginRound("capsule-turning")) return;
    const previousIndex = lastCapsuleShellIndexRef.current;
    const draw = Math.floor(Math.random() * (CAPSULE_SHELLS.length - (previousIndex < 0 ? 0 : 1)));
    const nextIndex = previousIndex < 0 ? draw : draw >= previousIndex ? draw + 1 : draw;
    lastCapsuleShellIndexRef.current = nextIndex;
    setCapsuleShellIndex(nextIndex);
    scheduleDraw(() => {
      setPhase("capsule-rolling");
      scheduleDraw(() => setPhase("capsule-dispensing"), 1500);
    }, 850);
  };

  const startFortuneRound = () => {
    if (!beginRound("fortune-shaking")) return;
    setFortuneShakeCount(FORTUNE_SHAKES_REQUIRED);
    scheduleDraw(() => {
      setPhase("fortune-falling");
      scheduleDraw(revealWinner, 850);
    }, 1150);
  };

  const startFishingRound = () => {
    if (!beginRound("fishing-waiting")) return;
    setFishingSceneSpot((current) => {
      if (current < 0) return Math.floor(Math.random() * FISHING_SCENE_COUNT);
      const next = Math.floor(Math.random() * (FISHING_SCENE_COUNT - 1));
      return next >= current ? next + 1 : next;
    });
    fishingPullCountRef.current = 0;
    setFishingPullCount(0);
    setFishingClickPulse(0);
    scheduleDraw(() => setPhase("fishing-bite"), 1450);
  };

  const resetRound = () => {
    if (drawTimerRef.current !== null) clearTimeout(drawTimerRef.current);
    drawTimerRef.current = null;
    pendingWinnerRef.current = null;
    fortuneGestureRef.current.active = false;
    setRandomShop(null);
    setPhase("ready");
    setCoinInserted(false);
    setIsCoinDragging(false);
    coinGestureRef.current.active = false;
    updateCoinOffset({ x: 0, y: 0 });
    setFortuneShakeCount(0);
    fishingPullCountRef.current = 0;
    setFishingPullCount(0);
    setFishingClickPulse(0);
    if (randomMode === "fishing") startFishingRound();
  };

  const changeMode = (mode: RandomMode) => {
    if (phaseRef.current !== "ready") return;
    if (drawTimerRef.current !== null) clearTimeout(drawTimerRef.current);
    drawTimerRef.current = null;
    pendingWinnerRef.current = null;
    setRandomMode(mode);
    setRandomShop(null);
    setPhase("ready");
    setCoinInserted(false);
    setIsCoinDragging(false);
    coinGestureRef.current.active = false;
    updateCoinOffset({ x: 0, y: 0 });
    setFortuneShakeCount(0);
    fishingPullCountRef.current = 0;
    setFishingPullCount(0);
    setFishingClickPulse(0);
    fortuneGestureRef.current = { active: false, lastX: 0, direction: 0, segmentDistance: 0, reversals: 0 };
    if (mode === "fishing") startFishingRound();
  };

  const handleCoinPointerDown = (event: ReactPointerEvent<HTMLButtonElement>) => {
    if (phaseRef.current !== "ready" || coinInserted) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    const bounds = event.currentTarget.getBoundingClientRect();
    const offset = coinOffsetRef.current;
    coinGestureRef.current = {
      active: true,
      startX: event.clientX,
      startY: event.clientY,
      originX: offset.x,
      originY: offset.y,
      baseLeft: bounds.left - offset.x,
      baseTop: bounds.top - offset.y,
    };
    setIsCoinDragging(true);
  };

  const handleCoinPointerMove = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const gesture = coinGestureRef.current;
    const container = capsuleGameRef.current?.getBoundingClientRect();
    if (!gesture.active || !container) return;
    const coinBounds = event.currentTarget.getBoundingClientRect();
    const minX = container.left - gesture.baseLeft;
    const maxX = container.right - gesture.baseLeft - coinBounds.width;
    const minY = container.top - gesture.baseTop;
    const maxY = container.bottom - gesture.baseTop - coinBounds.height;
    const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
    updateCoinOffset({
      x: clamp(gesture.originX + event.clientX - gesture.startX, minX, maxX),
      y: clamp(gesture.originY + event.clientY - gesture.startY, minY, maxY),
    });
  };

  const handleCoinPointerUp = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const gesture = coinGestureRef.current;
    if (!gesture.active) return;
    gesture.active = false;
    setIsCoinDragging(false);
    const slot = capsuleSlotRef.current?.getBoundingClientRect();
    const droppedInSlot = slot
      && event.clientX >= slot.left - 18
      && event.clientX <= slot.right + 18
      && event.clientY >= slot.top - 18
      && event.clientY <= slot.bottom + 18;
    if (droppedInSlot) snapCoinToSlot(event.currentTarget);
    else updateCoinOffset({ x: 0, y: 0 });
  };

  const handleCoinPointerCancel = () => {
    coinGestureRef.current.active = false;
    setIsCoinDragging(false);
    updateCoinOffset({ x: 0, y: 0 });
  };

  const handleCoinKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    if (phaseRef.current !== "ready" || coinInserted) return;
    snapCoinToSlot(event.currentTarget);
  };

  const handleFortunePointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (phaseRef.current !== "ready") return;
    event.currentTarget.setPointerCapture(event.pointerId);
    fortuneGestureRef.current = { active: true, lastX: event.clientX, direction: 0, segmentDistance: 0, reversals: 0 };
    setFortuneShakeCount(0);
  };

  const handleFortunePointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const gesture = fortuneGestureRef.current;
    if (!gesture.active || phaseRef.current !== "ready") return;
    const delta = event.clientX - gesture.lastX;
    gesture.lastX = event.clientX;
    if (Math.abs(delta) < 2) return;
    const direction = Math.sign(delta);
    if (gesture.direction === 0) {
      gesture.direction = direction;
      gesture.segmentDistance = Math.abs(delta);
      return;
    }
    if (direction === gesture.direction) {
      gesture.segmentDistance += Math.abs(delta);
      return;
    }
    if (gesture.segmentDistance >= 20) {
      gesture.reversals += 1;
      setFortuneShakeCount(Math.min(gesture.reversals, FORTUNE_SHAKES_REQUIRED));
    }
    gesture.direction = direction;
    gesture.segmentDistance = Math.abs(delta);
    if (gesture.reversals >= FORTUNE_SHAKES_REQUIRED) {
      gesture.active = false;
      startFortuneRound();
    }
  };

  const handleFortunePointerUp = () => {
    fortuneGestureRef.current.active = false;
  };

  const pullFishingLine = () => {
    const currentPhase = phaseRef.current;
    if (currentPhase !== "fishing-bite" && currentPhase !== "fishing-catching") return;
    const nextCount = fishingPullCountRef.current + 1;
    fishingPullCountRef.current = nextCount;
    setFishingPullCount(nextCount);
    setFishingClickPulse((current) => current + 1);
    if (currentPhase === "fishing-bite") setPhase("fishing-catching");
    if (nextCount >= FISH_PULLS_REQUIRED) {
      setPhase("fishing-landed");
      scheduleDraw(revealWinner, 850);
    }
  };

  useEffect(() => () => {
    if (drawTimerRef.current !== null) clearTimeout(drawTimerRef.current);
  }, []);

  return (
    <div className="home-page page-container">
      <section className="home-dashboard" id="decide" aria-label="早餐推薦與互動抽選">
        <div className="home-left-column">
          <div className="hero-copy decision-panel">
            <div className="eyebrow"><span className="eyebrow-dot" /> 政大周邊早餐指南 <span className="demo-tag">{breakfastShops.length} 家測試名單</span></div>
            <h1 id="home-title">今天早餐<br /><span>吃哪間？</span></h1>
            <p className="hero-lede">選擇障礙先休息一下。先看今日推薦，或玩一場互動抽選，讓早餐自己揭曉。</p>
          </div>

          <section className="recommend-section" id="today-picks" aria-labelledby="recommend-title">
            <div className="section-heading">
              <div><span className="section-kicker">A LITTLE INSPIRATION FOR TODAY</span><h2 id="recommend-title">今日推薦<span className="heading-period">.</span></h2><p>每天從 Excel 店家清單輪替三間，給選擇障礙一點剛剛好的提示。</p></div>
              <Link className="button-secondary" href="/nearby">店家總覽 <ArrowRight size={16} /></Link>
            </div>
            <div className="today-pick-grid">
              {dailyPicks.map((shop, index) => (
                <article className="today-pick-card" key={shop.id}>
                  <Link className="today-pick-main" href={`/shops/${shop.id}`} aria-label={`查看${shop.name}店家資訊`}>
                    <span className="today-pick-icon" aria-hidden="true">{shop.emoji}</span>
                    <span className="today-pick-copy"><small>今日推薦 0{index + 1}</small><strong>{shop.name}</strong><span>{getMenuPreview(shop)}</span></span>
                    <ArrowRight className="today-pick-arrow" size={17} aria-hidden="true" />
                  </Link>
                  <a className="today-pick-map-link" href={getGoogleMapsUrlForShop(shop)} target="_blank" rel="noopener noreferrer" aria-label={`在 Google 地圖查詢${shop.name}`} title="Google 地圖詳細查詢">
                    <MapPin size={15} aria-hidden="true" /><span>地圖查詢</span><ExternalLink size={12} aria-hidden="true" />
                  </a>
                </article>
              ))}
            </div>
            <p className="section-disclaimer">目前共 {breakfastShops.length} 家測試店家，其中 {convenienceStoreCount} 家便利商店依需求不整理商品與售價；未提供的地址、價格、營業時間、評分與步行距離不推估，請以店家最新公告為準。</p>
          </section>
        </div>

        <section className="home-game-panel" id="game-panel" aria-labelledby="home-game-title">
          <div className="home-game-heading">
            <div><span className="section-kicker">LET LUCK DECIDE</span><h2 id="home-game-title">玩一場，早餐就決定</h2><p>挑一種喜歡的玩法，抽中才揭曉店名。</p></div>
            <span className="game-count-tag">3 種互動</span>
          </div>
          <div className="random-mode-tabs" role="tablist" aria-label="選擇隨機選店玩法">
            <button className={`random-mode-tab ${randomMode === "capsule" ? "is-active" : ""}`} type="button" role="tab" aria-selected={randomMode === "capsule"} disabled={isBusy} onClick={() => changeMode("capsule")}>
              <span aria-hidden="true">🟡</span><span>扭蛋機</span>
            </button>
            <button className={`random-mode-tab ${randomMode === "fortune" ? "is-active" : ""}`} type="button" role="tab" aria-selected={randomMode === "fortune"} disabled={isBusy} onClick={() => changeMode("fortune")}>
              <span aria-hidden="true">🧧</span><span>算命籤</span>
            </button>
            <button className={`random-mode-tab ${randomMode === "fishing" ? "is-active" : ""}`} type="button" role="tab" aria-selected={randomMode === "fishing"} disabled={isBusy} onClick={() => changeMode("fishing")}>
              <span aria-hidden="true">🎣</span><span>釣早餐</span>
            </button>
          </div>

          <div className="random-play-card" role="tabpanel" aria-label={`${randomMode === "capsule" ? "扭蛋機" : randomMode === "fortune" ? "算命籤" : "釣早餐"}互動區`}>
            {randomMode === "capsule" && (
              <div ref={capsuleGameRef} className={`capsule-game ${phase === "capsule-turning" ? "is-turning" : ""} ${phase === "capsule-rolling" ? "is-rolling" : ""} ${phase === "capsule-dispensing" ? "is-dispensing" : ""} ${randomShop && randomMode === "capsule" ? "has-result" : ""}`}>
                <div className="capsule-machine">
                  <div className="capsule-dome" role="img" aria-label="透明球體裡裝滿彩色扭蛋">
                    <span className="capsule-globe-cap" aria-hidden="true" />
                    <div className="capsule-balls" aria-hidden="true">
                      {Array.from({ length: 24 }, (_, index) => <span className={`capsule-orb orb-color-${index % 6}`} key={index} />)}
                    </div>
                    <span className="capsule-window-shine" aria-hidden="true" />
                  </div>
                  <div className="capsule-machine-base">
                    <div className={`capsule-slot ${coinInserted ? "coin-ready" : ""}`}><span>投幣口</span><i ref={capsuleSlotRef} /></div>
                    <div className="capsule-brand-sticker">早知道<br /><small>早餐扭蛋</small></div>
                    <div className="capsule-knob-wrap">
                      <button className={`capsule-knob ${phase === "capsule-turning" ? "is-rotating" : ""}`} type="button" aria-label="轉動扭蛋機旋鈕" disabled={!coinInserted || isBusy} onClick={startCapsuleRound}>
                        <span><RotateCw size={23} aria-hidden="true" /></span>
                      </button>
                      <small>轉動旋鈕</small>
                    </div>
                  </div>
                  <div className="capsule-output-tray">
                    <span className="capsule-output-mouth" aria-hidden="true" />
                    {phase === "capsule-dispensing" && (
                      <button
                        className="capsule-release"
                        type="button"
                        aria-label={`點擊${CAPSULE_SHELLS[capsuleShellIndex].name}扭蛋，揭曉早餐店`}
                        style={{ background: `linear-gradient(180deg, #e2e7edcf 0 49%, ${CAPSULE_SHELLS[capsuleShellIndex].color} 50% 100%)` }}
                        onClick={revealWinner}
                      >
                        <span className="capsule-release-label" aria-hidden="true">?</span>
                      </button>
                    )}
                  </div>
                </div>
                <div className={`capsule-actions ${coinInserted ? "is-coin-inserted" : ""}`}>
                  {!coinInserted && (
                    <button
                      className={`capsule-drag-coin ${isCoinDragging ? "is-dragging" : ""}`}
                      type="button"
                      aria-label="拖曳硬幣到投幣口；也可按 Enter 或空白鍵投入"
                      disabled={isBusy}
                      style={{ transform: `translate3d(${coinOffset.x}px, ${coinOffset.y}px, 0)` }}
                      onPointerDown={handleCoinPointerDown}
                      onPointerMove={handleCoinPointerMove}
                      onPointerUp={handleCoinPointerUp}
                      onPointerCancel={handleCoinPointerCancel}
                      onKeyDown={handleCoinKeyDown}
                    >
                      <span className="capsule-coin-face"><Coins size={19} aria-hidden="true" /></span>
                      <small>拖曳投幣</small>
                    </button>
                  )}
                  <p aria-live="polite">{phase === "capsule-turning" ? "旋鈕正在轉動……" : phase === "capsule-rolling" ? "扭蛋正在透明球體裡滾動！" : phase === "capsule-dispensing" ? "扭蛋滾出來了，點擊它揭曉早餐店！" : coinInserted ? "硬幣已投入，轉動旋鈕開始抽選。" : "拖曳金幣到投幣口，再轉動旋鈕。"}</p>
                </div>
              </div>
            )}

            {randomMode === "fortune" && (
              <div className={`fortune-game ${phase === "fortune-shaking" ? "is-shaking" : ""} ${phase === "fortune-falling" || randomShop && randomMode === "fortune" ? "is-falling has-result" : ""}`}>
                <div className="fortune-counter" aria-label={`搖籤進度 ${fortuneShakeCount} / ${FORTUNE_SHAKES_REQUIRED}`}>
                  {Array.from({ length: FORTUNE_SHAKES_REQUIRED }, (_, index) => <span className={index < fortuneShakeCount ? "is-counted" : ""} key={index} />)}
                  <small>{fortuneShakeCount}/{FORTUNE_SHAKES_REQUIRED} 搖</small>
                </div>
                <div className="fortune-stage">
                  <span className="fortune-sparkle sparkle-one" aria-hidden="true">✦</span><span className="fortune-sparkle sparkle-two" aria-hidden="true">✧</span>
                  <div className="fortune-sticks" aria-hidden="true"><i /><i /><i /><i /><i /><i /></div>
                  <div className="fortune-tube" aria-hidden="true"><span>早</span><span>知道</span></div>
                  {(phase === "fortune-falling" || randomShop && randomMode === "fortune") && <div className="fortune-dropped-stick" aria-hidden="true"><span>早餐籤</span><i>✧</i></div>}
                  <div
                    className="fortune-drag-catcher"
                    role="button"
                    tabIndex={0}
                    aria-label="按住並左右拖曳籤筒，來回搖動四次抽籤"
                    onPointerDown={handleFortunePointerDown}
                    onPointerMove={handleFortunePointerMove}
                    onPointerUp={handleFortunePointerUp}
                    onPointerCancel={handleFortunePointerUp}
                    onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); startFortuneRound(); } }}
                  />
                </div>
                <div className="fortune-instructions">
                  <p aria-live="polite">{phase === "fortune-shaking" ? "籤筒正在搖晃……" : phase === "fortune-falling" ? "有一支籤掉出來了！" : "按住籤筒左右拖曳，來回搖四次。"}</p>
                  <button className="fortune-assist-button" type="button" disabled={isBusy} onClick={startFortuneRound}><Dices size={15} aria-hidden="true" />幫我搖籤</button>
                </div>
              </div>
            )}

            {randomMode === "fishing" && (
              <div className={`fishing-game scene-spot-${fishingSceneSpot} ${phase === "fishing-waiting" ? "is-waiting" : ""} ${phase === "fishing-bite" ? "is-biting" : ""} ${phase === "fishing-catching" ? "is-catching" : ""} ${phase === "fishing-landed" ? "is-landed" : ""} ${randomShop && randomMode === "fishing" ? "has-result" : ""} ${fishingPulseClass}`}>
                <div className="fishing-first-person">
                  <div className="fishing-distant-bank" aria-hidden="true" />
                  <div className="fishing-lake-water" aria-hidden="true" />
                  <div className="fishing-water-glints" aria-hidden="true" />
                  <span className="fishing-fish-shadow" aria-hidden="true">🐟</span>
                  <div className="fishing-ripples fishing-ripple-one" aria-hidden="true" />
                  <div className="fishing-ripples fishing-ripple-two" aria-hidden="true" />
                  <div className="fishing-line-first-person" aria-hidden="true"><span className="fishing-float" /></div>
                  {(phase === "fishing-catching" || phase === "fishing-landed" || randomShop && randomMode === "fishing") && <span className="fishing-caught-fish" aria-hidden="true">🐟</span>}
                  <div className="fishing-rod-first-person" aria-hidden="true"><i /></div>
                  <button className="fishing-tap-area" type="button" disabled={phase !== "fishing-bite" && phase !== "fishing-catching"} onClick={pullFishingLine} aria-label="魚上鉤後點擊或觸碰水面畫面，拉動魚竿收線">
                    <span className="fishing-bite-prompt" aria-live="polite">
                      {phase === "fishing-waiting" ? "魚線放下了，看看浮標……" : phase === "fishing-bite" ? "魚上鉤了！浮標在動，點一下拉竿！" : phase === "fishing-catching" ? "咬住了！再點一下，把魚拉上來！" : phase === "fishing-landed" ? "魚已上岸！早餐店即將揭曉" : "第一人稱釣魚 · 等待魚訊"}
                    </span>
                    <span className="fishing-tap-cue">{phase === "fishing-bite" ? "點擊提竿" : phase === "fishing-catching" ? `點擊收線 ${fishingPullCount}/${FISH_PULLS_REQUIRED}` : phase === "fishing-landed" ? "上岸成功" : "浮標有動靜時點擊畫面"}</span>
                  </button>
                </div>
                <div className="fishing-bottom-hud">
                  <div className="fishing-progress-copy">
                    <div className="fishing-pull-dots" aria-label={`提竿進度 ${fishingPullCount} / ${FISH_PULLS_REQUIRED}`}>
                      {Array.from({ length: FISH_PULLS_REQUIRED }, (_, index) => <span className={index < fishingPullCount ? "is-pulled" : ""} key={index} />)}
                      <strong>{fishingPullCount}/{FISH_PULLS_REQUIRED}</strong>
                    </div>
                    <p>{phase === "fishing-waiting" ? "魚線已放下，正在等魚上鉤……" : phase === "fishing-bite" ? "有魚咬餌！現在點擊畫面拉起魚竿。" : phase === "fishing-catching" ? "持續點擊，把早餐魚拉回岸邊。" : phase === "fishing-landed" ? "成功上岸！正在打開早餐驚喜。" : "選擇釣早餐後，浮標有訊號時記得提竿。"}</p>
                  </div>
                  <span className="fishing-viewpoint-tag"><Fish size={14} aria-hidden="true" /> 第一人稱視角</span>
                </div>
              </div>
            )}
            {randomShop && (
              <div className="random-result random-result-home random-result-in-game" aria-live="polite">
                <span className="random-result-label"><Sparkles size={15} aria-hidden="true" /> {randomMode === "fishing" ? "魚已上岸！今天釣到" : randomMode === "fortune" ? "籤上寫著這間早餐店" : "扭蛋驚喜是"}</span>
                <strong>{randomShop.name}！</strong>
                <div className="random-facts">
                  <span>{getMenuPreview(randomShop)}</span>
                  {randomShop.signature?.price !== undefined && <span>招牌參考價 NT${randomShop.signature.price}</span>}
                  <span><MapPin size={14} /> {getDisplayAddress(randomShop)}</span>
                  {randomShop.openingHours && <span>營業時間：{randomShop.openingHours}</span>}
                </div>
                <div className="random-actions">
                  <button className="button-yellow" type="button" onClick={() => setLocation(`/shops/${randomShop.id}`)}>看店家資訊 <ArrowRight size={16} /></button>
                  <a className="button-ghost-light maps-result-link" href={getGoogleMapsUrlForShop(randomShop)} target="_blank" rel="noopener noreferrer"><MapPin size={15} /> Google 地圖詳細查詢 <ExternalLink size={13} /></a>
                  <button className="button-ghost-light reroll-button" type="button" onClick={resetRound}><RefreshCw size={15} /> 換一家</button>
                </div>
              </div>
            )}
          </div>

          <p className="hero-note">先投幣再轉旋鈕、拖曳籤筒搖籤，或等魚訊後點擊提竿；抽中時才公布店名。</p>
        </section>
      </section>

      <section className="hero-map-card home-google-map-card home-map-section" id="nearby-map" aria-labelledby="hero-map-title">
          <div className="hero-map-heading">
            <div><span className="section-kicker">NCCU BREAKFAST MAP</span><h2 id="hero-map-title">政大周邊早餐地圖</h2></div>
            <a className="map-vintage-tag" href={googleMyMapsEmbedUrl} target="_blank" rel="noopener noreferrer" aria-label="另開線上 Google My Maps，需要網路"><span>Google My Maps · 線上</span><ExternalLink size={12} aria-hidden="true" /></a>
          </div>
          <p className="home-map-intro">離線版保留你提供的 23 個圖釘座標；底圖改為本機座標圖，不載入 Google 圖磚。</p>
          <OfflineBreakfastMap />
          <div className="home-map-actions">
            <a className="button-primary hero-map-google" href={googleMyMapsEmbedUrl} target="_blank" rel="noopener noreferrer">
              開啟線上 Google My Maps（需網路） <ExternalLink size={14} aria-hidden="true" />
            </a>
            <a className="home-map-search" href={googleMapsSearchUrl} target="_blank" rel="noopener noreferrer">
              Google Maps 搜尋附近早餐（需網路） <ArrowRight size={14} aria-hidden="true" />
            </a>
          </div>
          <p className="interactive-map-note">本機座標圖不含道路底圖，並不會自動同步 My Maps；更新圖釘時，請重新匯出 KML 並執行 tools/build_offline_map.py。</p>
      </section>
    </div>
  );
}
