import { ArrowLeft, ArrowUpRight, Clock3, ExternalLink, MapPin, Navigation, Utensils } from "lucide-react";
import { Link, useRoute } from "wouter";
import { getDisplayAddress, getGoogleMapsUrlForShop, getShopById, getShopTypeLabels } from "@/lib/breakfast-data";

export default function ShopDetail() {
  const [, params] = useRoute("/shops/:id");
  const shop = getShopById(params?.id);

  if (!shop) {
    return <div className="page-container content-page empty-results"><span className="empty-icon">☀</span><h1>找不到這間早餐店</h1><p>這筆資料可能不在目前匯入的測試名單中。</p><Link className="button-secondary" href="/nearby">回到店家總覽</Link></div>;
  }

  const directionsUrl = getGoogleMapsUrlForShop(shop);
  const addressLabel = getDisplayAddress(shop);
  const shopLabels = getShopTypeLabels(shop);
  const menuItems = [
    ...(shop.signature ? [{ item: shop.signature, isSignature: true }] : []),
    ...shop.popularItems.map((item) => ({ item, isSignature: false })),
  ];

  return (
    <div className="page-container content-page detail-page">
      <Link className="back-link" href="/nearby"><ArrowLeft size={16} /> 店家總覽</Link>
      <div className="detail-layout">
        <div className="detail-main">
          <div className="detail-title-block">
            <span className="section-kicker">A LITTLE BREAKFAST SPOT</span>
            <div className="detail-title-row">
              <div><span className="demo-tag">Excel 測試名單・資料待持續核對</span><h1>{shop.name}</h1><p className="detail-address-line"><MapPin size={14} /> {addressLabel}</p></div>
              <span className="detail-emoji" aria-hidden="true">{shop.emoji}</span>
            </div>
            {shop.description
              ? <p className="detail-description">{shop.description}</p>
              : shop.businessCategory === "便利商店"
                ? <p className="detail-description">依你的指示，此便利商店只列店家與地圖連結，不整理商品與售價。</p>
                : <p className="detail-description">店家介紹尚未提供。</p>}
            {shop.userNote && <p className="detail-description"><strong>Excel 備註：</strong>{shop.userNote}</p>}
            <div className="detail-tags">
              {shopLabels.length > 0
                ? shopLabels.map((category) => <span key={category}>{category}</span>)
                : <span>餐點類型尚未整理</span>}
              {shop.openingHours && <span><Clock3 size={14} /> {shop.openingHours}</span>}
            </div>
          </div>

          <section className="detail-card" aria-labelledby="popular-title">
            <div className="detail-section-title"><span className="detail-section-icon"><Utensils size={18} /></span><div><h2 id="popular-title">餐點參考</h2><p>只列出表格中已有名稱的餐點與價格</p></div></div>
            {menuItems.length > 0 ? (
              <div className="menu-list">
                {menuItems.map(({ item, isSignature }, index) => (
                  <div className="menu-row" key={`${item.name}-${index}`}>
                    <span className="menu-rank">{String(index + 1).padStart(2, "0")}</span>
                    <span className="menu-name"><strong>{item.name}</strong><small>{item.type ?? "早餐品項"}{isSignature ? "・工作表列為招牌" : "・資料列出的餐點"}</small></span>
                    {item.price !== undefined
                      ? <strong className="menu-price">NT${item.price}{item.priceQualifier ?? ""}</strong>
                      : <span className="menu-price-missing">價格未提供</span>}
                  </div>
                ))}
              </div>
            ) : (
              <div className="menu-empty">{shop.businessCategory === "便利商店" ? "依你的指示，不整理此便利商店販售的商品或售價。" : "這筆測試資料尚未收錄可引用的餐點或價格。"}</div>
            )}
            {shop.signatureNote && <p className="menu-disclaimer">招牌餐點備註：{shop.signatureNote}</p>}
            {shop.menuNote && <p className="menu-disclaimer">菜單價格備註：{shop.menuNote}；平台標價可能與店內不同。</p>}
            {!shop.menuNote && shop.businessCategory !== "便利商店" && <p className="menu-disclaimer">缺漏的菜單與價格維持未提供；實際供應與價格請以店家公告為準。</p>}
          </section>

          <section className="map-card" aria-labelledby="map-title">
            <div className="map-copy"><span className="section-kicker">AROUND YOU</span><h2 id="map-title">地圖與前往</h2><p><MapPin size={15} /> {addressLabel}</p>
              {shop.openingHours && <small>營業時間：{shop.openingHours}</small>}
              {shop.openingDays && <small>營業日：{shop.openingDays}</small>}
              <a className="button-primary map-button" href={directionsUrl} target="_blank" rel="noopener noreferrer">Google 地圖詳細查詢 <ArrowUpRight size={16} /></a>
              <small>開啟表格提供的 Google Maps 分享連結或店名／地址搜尋；請自行確認搜尋結果是否為正確分店。</small>
            </div>
            <div className="map-illustration" role="img" aria-label="政大周邊示意地圖，非店家實際座標">
              <svg viewBox="0 0 360 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
                <rect width="360" height="220" fill="#f3ead8" />
                <path d="M-10 50 C70 75 112 16 175 42 S279 89 370 48" fill="none" stroke="#fffaf0" strokeWidth="24" />
                <path d="M28 220 C55 165 103 143 138 110 S209 74 251 -15" fill="none" stroke="#fffaf0" strokeWidth="18" />
                <path d="M-20 175 C49 137 118 180 187 152 S297 132 375 162" fill="none" stroke="#fffaf0" strokeWidth="15" />
                <path d="M33 105 C93 95 132 127 171 131 S242 115 300 83" fill="none" stroke="#eeaa52" strokeWidth="3" strokeDasharray="6 7" strokeLinecap="round" />
                <circle cx="171" cy="131" r="18" fill="#184c3a" opacity=".14" /><circle cx="171" cy="131" r="8" fill="#184c3a" stroke="#fff8ea" strokeWidth="4" />
                <g fill="#829276" opacity=".52"><rect x="272" y="24" width="40" height="24" rx="7" /><rect x="73" y="153" width="46" height="27" rx="9" /><rect x="230" y="173" width="66" height="20" rx="8" /></g>
                <g fill="#75816f" fontFamily="sans-serif" fontSize="9"><text x="244" y="110">指南路</text><text x="53" y="84">校園小徑</text><text x="200" y="200">政大周邊・示意</text></g>
              </svg>
              <span className="map-pin-bubble"><MapPin size={14} fill="currentColor" /> 位置示意</span>
              <span className="map-label">非店家實際座標</span>
            </div>
          </section>

          <section className="detail-source-card" aria-label="資料來源與查核備註">
            <details>
              <summary><span>資料來源與查核備註</span><small>{shop.sourceUrls.length} 個來源・整理於 {shop.verifiedOn || "未註明日期"}</small></summary>
              {shop.sourceNote && <p className="source-summary">{shop.sourceNote}</p>}
              {shop.sourceConfidence && <p className="source-confidence">Excel 原始工作表的來源查核信心：{shop.sourceConfidence}</p>}
              {shop.sourceUrls.length > 0 ? (
                <ul className="source-list">
                  {shop.sourceUrls.map((source, index) => (
                    <li key={`${source.url}-${index}`}><a href={source.url} target="_blank" rel="noopener noreferrer">{source.label || "資料來源"} <ExternalLink size={12} /></a><span>{source.supports}</span></li>
                  ))}
                </ul>
              ) : <p>工作表中沒有提供外部來源連結。</p>}
            </details>
          </section>
        </div>

        <aside className="detail-aside">
          <section className="visit-card">
            <span className="visit-card-kicker">GOOD TO KNOW</span>
            <h2>出發前<br />先看一下。</h2>
            {shop.openingHours && <div className="visit-fact"><span className="visit-fact-icon"><Clock3 size={17} /></span><span><small>表格所列營業時間</small><strong>{shop.openingHours}</strong></span></div>}
            {shop.openingDays && <div className="visit-fact"><span className="visit-fact-icon"><Clock3 size={17} /></span><span><small>表格所列營業日</small><strong>{shop.openingDays}</strong></span></div>}
            {!shop.openingHours && !shop.openingDays && <p className="visit-missing">Excel 尚未提供營業時間；出發前請查店家最新公告。</p>}
            <div className="visit-address"><MapPin size={16} /><span>{addressLabel}</span></div>
            <a className="button-primary visit-button" href={directionsUrl} target="_blank" rel="noopener noreferrer">Google 地圖詳細查詢 <Navigation size={16} /></a>
            <p>未提供的評分、步行時間及價格不推估。</p>
          </section>
          <div className="detail-aside-note"><span>✳</span><p>目前是測試資料集；地址、菜單與營業狀態可能變動，請以店家最新資訊為準。</p></div>
        </aside>
      </div>
    </div>
  );
}
