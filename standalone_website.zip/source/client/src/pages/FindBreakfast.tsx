import { ArrowRight, Check, Filter, MapPin, RotateCcw, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { ShopCard } from "@/components/ShopCard";
import { breakfastShops, breakfastTypes, getMatchingShops, type BreakfastType } from "@/lib/breakfast-data";

type Filters = { budget: number | null; type: BreakfastType | "不限" };

function getInitialFilters(): Filters {
  const params = new URLSearchParams(window.location.search);
  const budgetParam = Number(params.get("budget"));
  const rawType = params.get("type");
  const type = breakfastTypes.includes(rawType as BreakfastType | "不限") ? rawType as BreakfastType | "不限" : "蛋餅";
  return {
    budget: Number.isFinite(budgetParam) && budgetParam > 0 ? budgetParam : 100,
    type,
  };
}

const budgetOptions: Array<{ label: string; value: number | null }> = [
  { label: "不限", value: null }, { label: "$70 以下", value: 70 }, { label: "$100 以下", value: 100 }, { label: "$150 以下", value: 150 },
];

export default function FindBreakfast() {
  const [, setLocation] = useLocation();
  const [filters, setFilters] = useState<Filters>(getInitialFilters);
  const [applied, setApplied] = useState<Filters>(getInitialFilters);
  const [isApplied, setIsApplied] = useState(true);
  const resultMatches = useMemo(() => getMatchingShops(applied), [applied]);
  const visibleShops = resultMatches.slice(0, 3);

  const updateFilters = (next: Filters) => {
    setFilters(next);
    setIsApplied(false);
  };

  const resetFilters = () => {
    const reset = { budget: 100, type: "蛋餅" as const };
    setFilters(reset);
    setApplied(reset);
    setIsApplied(true);
    setLocation("/find");
  };

  const applyFilters = () => {
    setApplied(filters);
    setIsApplied(true);
    const params = new URLSearchParams();
    if (filters.budget !== null) params.set("budget", String(filters.budget));
    if (filters.type !== "不限") params.set("type", filters.type);
    setLocation(`/find${params.size ? `?${params.toString()}` : ""}`);
  };

  return (
    <div className="page-container content-page find-page">
      <div className="page-heading">
        <span className="section-kicker">BREAKFAST, MADE SIMPLE</span>
        <h1>幫早晨，<span>少想一點。</span></h1>
        <p>可依已整理的菜單價格與餐點類型縮小選擇；不確定的資料不猜。</p>
      </div>

      <section className="filter-panel" aria-labelledby="filter-title">
        <div className="filter-panel-heading">
          <div className="filter-panel-icon"><SlidersHorizontal size={19} /></div>
          <div><h2 id="filter-title">今天想怎麼吃？</h2><p>只使用 Excel 中目前有資料的條件</p></div>
          <span className="demo-tag">{breakfastShops.length} 家測試資料</span>
        </div>

        <fieldset className="filter-group">
          <legend><span className="filter-number">01</span><span>選擇價格</span><small>只比對已列出的單品價格</small></legend>
          <div className="chip-row">
            {budgetOptions.map(({ label, value }) => (
              <button className={`choice-chip ${filters.budget === value ? "is-selected" : ""}`} type="button" key={label} onClick={() => updateFilters({ ...filters, budget: value })} aria-pressed={filters.budget === value}>
                {filters.budget === value && <Check size={14} />} {label}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset className="filter-group">
          <legend><span className="filter-number">02</span><span>選擇類型</span><small>依已整理的餐點名稱歸類</small></legend>
          <div className="chip-row type-chip-row">
            {breakfastTypes.map((type) => (
              <button className={`choice-chip ${filters.type === type ? "is-selected" : ""}`} type="button" key={type} onClick={() => updateFilters({ ...filters, type })} aria-pressed={filters.type === type}>
                {filters.type === type && <Check size={14} />} {type}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="filter-panel-footer">
          <span className="filter-hint"><Filter size={15} /> 價格缺漏的店家不推測符合預算</span>
          <div className="filter-actions">
            <button type="button" className="button-reset" onClick={resetFilters}><RotateCcw size={15} /> 重設</button>
            <button type="button" className="button-primary" onClick={applyFilters}>{isApplied ? "更新推薦" : "用這些條件找早餐"} <ArrowRight size={17} /></button>
          </div>
        </div>
      </section>

      <section className="results-section" aria-labelledby="results-title">
        <div className="section-heading results-heading">
          <div><span className="section-kicker">A FEW GOOD PICKS</span><h2 id="results-title">為你挑好的早餐<span className="heading-period">.</span></h2><p>{resultMatches.length > 3 ? "先替你精選 3 間" : `符合條件的測試店家 ${resultMatches.length} 間`}，一眼就能比較。</p></div>
          <span className="results-count"><strong>{visibleShops.length}</strong> <span>間推薦</span></span>
        </div>
        {visibleShops.length > 0 ? (
          <div className="shop-grid">
            {visibleShops.map((shop, index) => <ShopCard key={shop.id} shop={shop} rank={index + 1} />)}
          </div>
        ) : (
          <div className="empty-results"><span className="empty-icon">☀</span><h3>目前沒有可比對的店家</h3><p>可能尚未整理出符合這個類型或預算的菜單項目；試試「不限」或回首頁隨機抽選。</p><button className="button-secondary" type="button" onClick={resetFilters}>回到推薦條件 <ArrowRight size={16} /></button></div>
        )}
        <p className="section-disclaimer"><MapPin size={14} /> 預算篩選依 Excel 已列的餐點價格；未提供價格的店家不推測符合。步行時間請以 Google 地圖導航為準。</p>
      </section>
    </div>
  );
}
