import { MapPin, MoveUpRight } from "lucide-react";
import type { CSSProperties } from "react";
import { Link } from "wouter";
import { getDisplayAddress, getLowestListedPrice, getShopTypeLabels, type BreakfastShop } from "@/lib/breakfast-data";

export function ShopCard({ shop, rank }: { shop: BreakfastShop; rank?: number }) {
  const lowestPrice = getLowestListedPrice(shop);
  const shopLabels = getShopTypeLabels(shop);
  const priceLabel = shop.businessCategory === "便利商店"
    ? "商品與售價不特別整理"
    : lowestPrice !== undefined ? `查得項目最低 NT$${lowestPrice}` : "價格未提供";

  return (
    <article className="shop-card">
      <Link className="shop-card-link" href={`/shops/${shop.id}`} aria-label={`查看${shop.name}詳情`}>
        <div className="shop-card-top">
          <span className="shop-emoji" style={{ "--shop-accent": shop.accent } as CSSProperties} aria-hidden="true">
            {shop.emoji}
          </span>
          {rank ? <span className="rank-label">結果 {String(rank).padStart(2, "0")}</span> : <span className="demo-tag">測試資料</span>}
          <MoveUpRight className="shop-card-arrow" size={17} aria-hidden="true" />
        </div>
        <div className="shop-card-copy">
          <span className="shop-feature-label">{shop.featuredLabel}</span>
          <h3>{shop.name}</h3>
          <p>{getDisplayAddress(shop)}</p>
        </div>
        <div className="shop-card-metrics">
          <span><MapPin size={14} aria-hidden="true" /> 政大周邊店家</span>
          <strong>{priceLabel}</strong>
        </div>
        <div className="shop-card-categories">
          {shopLabels.length > 0
            ? shopLabels.slice(0, 3).map((category) => <span key={category}>{category}</span>)
            : <span>餐點資料待補</span>}
        </div>
      </Link>
    </article>
  );
}
