import { ArrowUpRight, MapPin } from "lucide-react";
import { Link } from "wouter";
import points from "@/lib/nccu-map-points.json";

export default function OfflineBreakfastMap() {
  return (
    <div className="offline-map-layout">
      <figure className="offline-map-figure">
        <img
          className="offline-map-image"
          src="./images/nccu-breakfast-offline.svg"
          alt="政大周邊早餐店離線座標圖，圖釘依 My Maps KML 的經緯度標出；背景為座標格線，不包含街道底圖。"
          width="1120"
          height="720"
          loading="lazy"
        />
        <figcaption>
          <MapPin size={14} aria-hidden="true" />
          <span>圖釘取自你提供的 My Maps KML；未封存 Google 街道底圖。</span>
        </figcaption>
      </figure>
      <div className="offline-map-directory">
        <div className="offline-map-directory-heading">
          <strong>地圖店家</strong>
          <span>{points.length} 個圖釘</span>
        </div>
        <ol className="offline-map-place-list" aria-label="離線地圖店家清單">
          {points.map((point, index) => (
            <li key={`${point.name}-${point.shopId ?? index}`}>
              {point.shopId ? (
                <Link className="offline-map-place-link" href={`/shops/${point.shopId}`}>
                  <span className="offline-map-place-number">{String(index + 1).padStart(2, "0")}</span>
                  <span className="offline-map-place-name">{point.shopName ?? point.name}</span>
                  <ArrowUpRight size={14} aria-hidden="true" />
                </Link>
              ) : (
                <span className="offline-map-place-link is-unmatched">
                  <span className="offline-map-place-number">{String(index + 1).padStart(2, "0")}</span>
                  <span className="offline-map-place-name">{point.name}</span>
                </span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
