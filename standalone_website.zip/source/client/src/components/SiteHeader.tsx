import { ArrowUpRight, Dices, Home, MapPin, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";

const brandMark = "./images/zaozhidao-mark.webp";

export function SiteHeader() {
  const [location, setLocation] = useLocation();
  const links = [
    { href: "/", label: "首頁", icon: Home },
    { href: "/", sectionId: "today-picks", label: "今日推薦", icon: Sparkles },
    { href: "/nearby", label: "店家總覽", icon: MapPin },
  ];
  const scrollToSection = (sectionId: string) => {
    const scroll = () => document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
    if (location !== "/") {
      setLocation("/");
      window.setTimeout(scroll, 120);
    } else {
      scroll();
    }
  };

  return (
    <header className="site-header">
      <div className="header-inner page-container">
        <Link href="/" className="brand" aria-label="早知道首頁">
          <img className="brand-mark" src={brandMark} alt="" />
          <span className="brand-copy">
            <strong>早知道</strong>
            <span>政大周邊早餐指南</span>
          </span>
        </Link>

        <nav className="desktop-nav" aria-label="主要導覽">
          {links.map(({ href, sectionId, label, icon: Icon }) => {
            const isCurrentPage = !sectionId && (href === "/" ? location === "/" : href === "/nearby" && location.startsWith("/nearby"));
            const contents = <><Icon size={16} strokeWidth={1.8} aria-hidden="true" />{label}</>;
            return sectionId ? (
              <a key={sectionId} href="#/" className="nav-link" onClick={(event) => { event.preventDefault(); scrollToSection(sectionId); }}>{contents}</a>
            ) : (
              <Link
                key={href}
                href={href}
                className={`nav-link ${isCurrentPage ? "is-active" : ""}`}
                aria-current={isCurrentPage ? "page" : undefined}
              >
                {contents}
              </Link>
            );
          })}
        </nav>

        <a className="header-action" href="#/" onClick={(event) => { event.preventDefault(); scrollToSection("decide"); }}>
          <Dices size={16} aria-hidden="true" />
          <span>幫我決定</span>
          <ArrowUpRight size={14} aria-hidden="true" />
        </a>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="page-container footer-inner">
        <Link className="footer-brand" href="/">
          <img src={brandMark} alt="" />
          <span>早知道</span>
        </Link>
        <p>少找一點，早餐吃好一點。</p>
        <span className="footer-note">Excel 測試名單・資訊可能變動</span>
      </div>
    </footer>
  );
}
