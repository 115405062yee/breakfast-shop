import importedShopRows from "./breakfast-shops.json";

export type BreakfastType = "蛋餅" | "吐司" | "漢堡" | "飯糰" | "飲品";
export type BusinessCategory = "便利商店";

export interface BreakfastItem {
  name: string;
  price?: number;
  priceQualifier?: "起";
  type?: BreakfastType;
}

export interface BreakfastSource {
  label: string;
  url: string;
  supports: string;
}

export interface BreakfastShop {
  id: string;
  name: string;
  description: string;
  address: string;
  googleMapsUrl: string;
  signature?: BreakfastItem;
  signatureNote?: string;
  popularItems: BreakfastItem[];
  menuNote?: string;
  categories: BreakfastType[];
  businessCategory?: BusinessCategory;
  userNote?: string;
  openingHours?: string;
  openingDays?: string;
  sourceConfidence?: string;
  sourceNote?: string;
  sourceUrls: BreakfastSource[];
  verifiedOn?: string;
  emoji: string;
  accent: string;
  featuredLabel: string;
}

interface ImportedShopRow {
  id: string;
  name: string;
  googleMapsUrl: string;
  address: string;
  signature: string | null;
  signatureNote: string;
  signaturePrice: number | null;
  otherItemsRaw: string;
  menuNote: string;
  openingHours: string;
  openingDays: string;
  description: string;
  sourceConfidence: string;
  sourceNote: string;
  sourceUrls: BreakfastSource[];
  verifiedOn: string;
  businessCategory?: BusinessCategory;
  userNote?: string;
}

const accentPalette = ["#e7a14d", "#6d9272", "#bd8262", "#d27b52", "#91a878", "#ce9c50"];

function getItemType(name: string): BreakfastType | undefined {
  if (/蛋餅/u.test(name)) return "蛋餅";
  if (/吐司|厚片/u.test(name)) return "吐司";
  if (/漢堡|滿分堡|蛋堡|堡/u.test(name)) return "漢堡";
  if (/飯糰/u.test(name)) return "飯糰";
  if (/飲品|咖啡|拿鐵|豆漿|紅茶|奶茶|米漿|果汁|茶/u.test(name)) return "飲品";
  return undefined;
}

function parseMenuItem(raw: string): BreakfastItem | undefined {
  const value = raw.trim();
  if (!value) return undefined;
  const priceMatch = value.match(/NT\$\s*([\d,]+)(\s*起)?/iu);
  const price = priceMatch ? Number(priceMatch[1].replace(/,/g, "")) : undefined;
  const name = value.replace(/\s*NT\$\s*[\d,]+(?:\s*起)?/iu, "").trim();
  if (!name) return undefined;
  const type = getItemType(name);
  return {
    name,
    ...(price !== undefined && Number.isFinite(price) ? { price } : {}),
    ...(priceMatch?.[2] ? { priceQualifier: "起" as const } : {}),
    ...(type ? { type } : {}),
  };
}

function parseOtherItems(raw: string): BreakfastItem[] {
  if (!raw.trim()) return [];
  const delimiter = raw.includes("；") ? /[；;]/u : /、/u;
  return raw.split(delimiter).map(parseMenuItem).filter((item): item is BreakfastItem => Boolean(item));
}

function getShopEmoji(categories: BreakfastType[], businessCategory?: BusinessCategory): string {
  if (businessCategory === "便利商店") return "🏪";
  if (categories.includes("蛋餅")) return "🍳";
  if (categories.includes("漢堡")) return "🍔";
  if (categories.includes("吐司")) return "🍞";
  if (categories.includes("飯糰")) return "🍙";
  if (categories.includes("飲品")) return "☕";
  return "☀️";
}

const rows = importedShopRows as unknown as ImportedShopRow[];

export const breakfastShops: BreakfastShop[] = rows.map((row, index) => {
  const signatureItem = row.signature ? parseMenuItem(row.signature) : undefined;
  if (signatureItem && row.signaturePrice !== null && Number.isFinite(row.signaturePrice)) {
    signatureItem.price = row.signaturePrice;
  }
  const popularItems = parseOtherItems(row.otherItemsRaw);
  const menuItems = [...(signatureItem ? [signatureItem] : []), ...popularItems];
  const categories = Array.from(
    new Set(menuItems.map((item) => item.type).filter((type): type is BreakfastType => Boolean(type))),
  );

  return {
    id: row.id,
    name: row.name,
    description: row.description,
    address: row.address,
    googleMapsUrl: row.googleMapsUrl,
    ...(signatureItem ? { signature: signatureItem } : {}),
    ...(row.signatureNote ? { signatureNote: row.signatureNote } : {}),
    popularItems,
    ...(row.menuNote ? { menuNote: row.menuNote } : {}),
    categories,
    ...(row.businessCategory ? { businessCategory: row.businessCategory } : {}),
    ...(row.userNote ? { userNote: row.userNote } : {}),
    ...(row.openingHours ? { openingHours: row.openingHours } : {}),
    ...(row.openingDays ? { openingDays: row.openingDays } : {}),
    ...(row.sourceConfidence ? { sourceConfidence: row.sourceConfidence } : {}),
    ...(row.sourceNote ? { sourceNote: row.sourceNote } : {}),
    sourceUrls: row.sourceUrls,
    ...(row.verifiedOn ? { verifiedOn: row.verifiedOn } : {}),
    emoji: getShopEmoji(categories, row.businessCategory),
    accent: accentPalette[index % accentPalette.length],
    featuredLabel: categories.length ? categories.slice(0, 2).join("・") : row.businessCategory ?? "店家資料",
  };
});

export const breakfastTypes: Array<BreakfastType | "不限"> = ["不限", "蛋餅", "吐司", "漢堡", "飯糰", "飲品"];

export function getShopById(id?: string): BreakfastShop | undefined {
  return breakfastShops.find((shop) => shop.id === id);
}

export function getGoogleMapsUrlForShop(shop: BreakfastShop): string {
  if (shop.googleMapsUrl.trim()) return shop.googleMapsUrl;
  const query = shop.address.trim() ? `${shop.name} ${shop.address}` : `${shop.name} 國立政治大學`;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

export function getDisplayAddress(shop: BreakfastShop): string {
  return shop.address.trim() || "地址尚未整理；可點 Google 地圖查看位置。";
}

export function getShopTypeLabels(shop: BreakfastShop): string[] {
  if (shop.categories.length > 0) return shop.categories;
  return shop.businessCategory ? [shop.businessCategory] : [];
}

export function getKnownPrices(shop: BreakfastShop): number[] {
  return [shop.signature?.price, ...shop.popularItems.map((item) => item.price)].filter(
    (price): price is number => typeof price === "number" && Number.isFinite(price),
  );
}

export function getLowestListedPrice(shop: BreakfastShop): number | undefined {
  const prices = getKnownPrices(shop);
  return prices.length ? Math.min(...prices) : undefined;
}

export function getMatchingShops({
  budget,
  type,
}: {
  budget: number | null;
  type: BreakfastType | "不限";
}): BreakfastShop[] {
  return breakfastShops.filter((shop) => {
    const matchesBudget = budget === null || getKnownPrices(shop).some((price) => price <= budget);
    const matchesType = type === "不限" || shop.categories.includes(type);
    return matchesBudget && matchesType;
  });
}
