// Standalone build: no Manus runtime config, API key, login, or backend endpoint.
window.__MANUS_CONFIG__ = Object.freeze({});
