# 早知道｜Standalone 原始碼

網站的交付入口是 ZIP 最外層 `index.html`；CSS 與 JavaScript 內嵌其中，圖片使用同層 `images/` 的相對路徑。解壓後可直接雙擊該入口或使用 VS Code Live Server。不要直接以瀏覽器開啟 `source/client/index.html`，該檔是 Vite 的開發原始碼入口，不是交付頁面。

## 重建交付版

此目錄含 React／TypeScript、Vite 原始碼與 `pnpm-lock.yaml`。在 `source/` 目錄執行：

```sh
pnpm install --frozen-lockfile
pnpm build:static
python3 tools/package_standalone.py ../
```

`package_standalone.py` 會將已建置 CSS 和 JavaScript 內嵌到上一層 `index.html`，並複製本機圖片與 robots.txt；頁面不依賴 Manus config/API。安裝依賴與重建需要網路，但打包完成的網站瀏覽不需要網路。

## 離線資料與地圖

店家資料位於 `client/src/lib/breakfast-shops.json`。原始 My Maps KML 與地圖產生器分別在 `data/nccu-breakfast-mymaps.kml`、`tools/build_offline_map.py`；重跑腳本會更新店點 JSON 與 `client/public/images/nccu-breakfast-offline.svg`。目前 KML 有 23 個圖釘；`BigBurger 比飽嗝大漢堡早午餐` 與 `三三活力早餐店` 不在 KML 中，所以不猜測座標。

離線 SVG 僅繪製 KML 經緯度與座標格線，不包含 Google 街道底圖。Google Maps 外連需網路。原始 starter 隨附的 `server/` 與資料庫範本保留供參考，早餐網站靜態版不會啟動或呼叫它們，也不需平台金鑰、登入或資料庫。
