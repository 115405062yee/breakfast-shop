// Platform-specific metadata is intentionally omitted from this self-hosted copy.
export default {};
