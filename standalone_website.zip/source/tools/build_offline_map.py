#!/usr/bin/env python3
"""Build a local, offline coordinate plot from the supplied My Maps KML.

The SVG deliberately does not include or cache Google's basemap tiles. It plots
only the user-provided KML placemark coordinates over a labelled coordinate grid.
"""
from __future__ import annotations

import json
import math
import re
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KML = ROOT / "data" / "nccu-breakfast-mymaps.kml"
SHOPS_JSON = ROOT / "client" / "src" / "lib" / "breakfast-shops.json"
POINTS_JSON = ROOT / "client" / "src" / "lib" / "nccu-map-points.json"
SVG = ROOT / "client" / "public" / "images" / "nccu-breakfast-offline.svg"
NS = {"k": "http://www.opengis.net/kml/2.2"}
ALIASES = {"木硯早食WOODINK": "WOOD INK 木硯"}
PALETTE = ["#f04f6b", "#1769d2", "#05a98d", "#e5a900", "#8254d9", "#e755ac"]


def norm(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).lower()
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]", "", value)


def load_points() -> list[dict]:
    shops = json.loads(SHOPS_JSON.read_text(encoding="utf-8"))
    by_name = {norm(shop["name"]): shop for shop in shops}
    root = ET.parse(KML).getroot()
    points: list[dict] = []
    for placemark in root.findall(".//k:Placemark", NS):
        name = placemark.findtext("k:name", default="", namespaces=NS).strip()
        node = placemark.find(".//k:Point/k:coordinates", NS)
        if node is None or not node.text:
            continue
        parts = node.text.strip().split(",")
        if len(parts) < 2:
            continue
        lon, lat = float(parts[0]), float(parts[1])
        matched_name = ALIASES.get(name, name)
        normalized = norm(matched_name)
        shop = by_name.get(normalized)
        if shop is None:
            shop = next((s for n, s in by_name.items() if n in normalized or normalized in n), None)
        points.append({
            "name": name,
            "lat": lat,
            "lon": lon,
            "shopId": shop["id"] if shop else None,
            "shopName": shop["name"] if shop else None,
        })
    if not points:
        raise SystemExit("No point placemarks found in KML")
    POINTS_JSON.parent.mkdir(parents=True, exist_ok=True)
    POINTS_JSON.write_text(json.dumps(points, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return points


def cluster_indices(points: list[dict], xy: list[tuple[float, float]], threshold: float = 25) -> list[list[int]]:
    parents = list(range(len(points)))

    def find(i: int) -> int:
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parents[rb] = ra

    for i in range(len(xy)):
        for j in range(i + 1, len(xy)):
            if math.dist(xy[i], xy[j]) < threshold:
                union(i, j)
    groups: dict[int, list[int]] = {}
    for i in range(len(points)):
        groups.setdefault(find(i), []).append(i)
    return list(groups.values())


def build_svg(points: list[dict]) -> str:
    width, height = 1120, 720
    left, top, map_w, map_h = 90, 128, 940, 480
    lons = [p["lon"] for p in points]
    lats = [p["lat"] for p in points]
    pad_lon, pad_lat = 0.00065, 0.00055
    min_lon, max_lon = min(lons) - pad_lon, max(lons) + pad_lon
    min_lat, max_lat = min(lats) - pad_lat, max(lats) + pad_lat
    center_lat = (min_lat + max_lat) / 2
    x_m = [(lon - (min_lon + max_lon) / 2) * 111320 * math.cos(math.radians(center_lat)) for lon in lons]
    y_m = [((min_lat + max_lat) / 2 - lat) * 110540 for lat in lats]
    box_w = (max_lon - min_lon) * 111320 * math.cos(math.radians(center_lat))
    box_h = (max_lat - min_lat) * 110540
    scale = min(map_w / box_w, map_h / box_h)
    origin_x = left + (map_w - box_w * scale) / 2
    origin_y = top + (map_h - box_h * scale) / 2
    xy = [(origin_x + (x + box_w / 2) * scale, origin_y + (y + box_h / 2) * scale) for x, y in zip(x_m, y_m)]

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-labelledby="map-title map-desc">',
        '<title id="map-title">政大周邊早餐店離線座標圖</title>',
        '<desc id="map-desc">以您提供的 Google My Maps KML 中的店點經緯度繪製；背景只有經緯網格，不包含 Google 街道圖磚或道路底圖。</desc>',
        '<defs><pattern id="smallGrid" width="48" height="48" patternUnits="userSpaceOnUse"><path d="M 48 0 L 0 0 0 48" fill="none" stroke="#d9e5e3" stroke-width="1" stroke-dasharray="2 5"/></pattern><filter id="shadow" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#195d70" flood-opacity=".16"/></filter></defs>',
        '<rect width="1120" height="720" rx="28" fill="#fffaf0"/>',
        '<rect x="18" y="18" width="1084" height="684" rx="24" fill="#fffdf8" stroke="#153e57" stroke-width="3"/>',
        '<text x="54" y="66" font-family="system-ui, sans-serif" font-size="30" font-weight="800" fill="#153e57">政大周邊早餐店位置圖</text>',
        f'<text x="55" y="94" font-family="system-ui, sans-serif" font-size="15" font-weight="600" fill="#5d7580">離線座標圖 · {len(points)} 個 My Maps 圖釘 · WGS 84</text>',
        f'<rect x="{left}" y="{top}" width="{map_w}" height="{map_h}" rx="18" fill="#edf7f6" stroke="#acd5d2" stroke-width="2"/>',
        f'<rect x="{left}" y="{top}" width="{map_w}" height="{map_h}" rx="18" fill="url(#smallGrid)"/>',
    ]

    # Coordinate grid and labels (not a fabricated street network).
    for i in range(5):
        x = left + map_w * i / 4
        lon = min_lon + (max_lon - min_lon) * i / 4
        parts.append(f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + map_h}" stroke="#9ebdbd" stroke-width="1" stroke-dasharray="4 7" opacity=".68"/>')
        parts.append(f'<text x="{x:.1f}" y="{top + map_h + 23}" text-anchor="middle" font-family="ui-monospace, monospace" font-size="12" fill="#557079">{lon:.4f}°E</text>')
    for i in range(5):
        y = top + map_h * i / 4
        lat = max_lat - (max_lat - min_lat) * i / 4
        parts.append(f'<line x1="{left}" y1="{y:.1f}" x2="{left + map_w}" y2="{y:.1f}" stroke="#9ebdbd" stroke-width="1" stroke-dasharray="4 7" opacity=".68"/>')
        parts.append(f'<text x="{left - 12}" y="{y + 4:.1f}" text-anchor="end" font-family="ui-monospace, monospace" font-size="12" fill="#557079">{lat:.4f}°N</text>')

    # Plot every KML point at its actual coordinate. Nearby points may overlap;
    # count bubbles show how many places are in each dense cluster.
    for i, (p, (x, y)) in enumerate(zip(points, xy)):
        color = PALETTE[i % len(PALETTE)]
        safe_name = (p["name"].replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                     .replace('"', "&quot;"))
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="8" fill="{color}" fill-opacity=".88" stroke="#fffdf8" stroke-width="2"><title>{safe_name} · {p["lat"]:.6f}, {p["lon"]:.6f}</title></circle>')
    for group in cluster_indices(points, xy):
        if len(group) < 2:
            continue
        cx = sum(xy[i][0] for i in group) / len(group)
        cy = sum(xy[i][1] for i in group) / len(group)
        bubble_y = max(top + 22, cy - 34)
        parts.append(f'<line x1="{cx:.1f}" y1="{cy:.1f}" x2="{cx:.1f}" y2="{bubble_y + 10:.1f}" stroke="#153e57" stroke-width="1.5" opacity=".62"/>')
        parts.append(f'<g filter="url(#shadow)"><rect x="{cx - 22:.1f}" y="{bubble_y - 14:.1f}" width="44" height="28" rx="14" fill="#153e57"/><text x="{cx:.1f}" y="{bubble_y + 5:.1f}" text-anchor="middle" font-family="system-ui, sans-serif" font-size="13" font-weight="800" fill="#fff">{len(group)} 店</text></g>')

    # North marker and a clearly visible legend.
    parts.extend([
        '<g transform="translate(1010 152)"><circle cx="0" cy="0" r="28" fill="#fffdf8" stroke="#153e57" stroke-width="2"/><path d="M0 -17 L8 8 L0 3 L-8 8 Z" fill="#f04f6b"/><text x="0" y="43" text-anchor="middle" font-family="system-ui, sans-serif" font-size="13" font-weight="800" fill="#153e57">北</text></g>',
        '<rect x="55" y="660" width="1010" height="25" rx="12" fill="#e9f4ee"/>',
        '<text x="560" y="678" text-anchor="middle" font-family="system-ui, sans-serif" font-size="13" font-weight="600" fill="#31545d">圖釘座標來自使用者提供的 My Maps KML；未包含 Google 街道底圖。點選下方店名清單可查看店家。</text>',
        '<text x="1045" y="644" text-anchor="end" font-family="system-ui, sans-serif" font-size="12" fill="#557079">座標格線非道路</text>',
        '</svg>',
    ])
    return "\n".join(parts) + "\n"


def main() -> None:
    points = load_points()
    SVG.parent.mkdir(parents=True, exist_ok=True)
    SVG.write_text(build_svg(points), encoding="utf-8")
    print(f"Generated {len(points)} KML points: {POINTS_JSON} and {SVG}")
    missing = [p["name"] for p in points if not p["shopId"]]
    if missing:
        print("Unmatched shop names:", ", ".join(missing))


if __name__ == "__main__":
    main()
