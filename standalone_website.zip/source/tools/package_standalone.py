#!/usr/bin/env python3
"""Package the static Vite build as a file://-friendly standalone website.

Usage from this directory's parent source folder, after pnpm build:static:
    python3 tools/package_standalone.py ../

The output folder contains one self-contained index.html (inline CSS/JS) plus
relative local image assets and robots.txt. No module imports or platform API
script are loaded by the HTML entrypoint.
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "dist" / "public"
OUT = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else ROOT.parent


def one_asset(folder: Path, suffix: str) -> Path:
    found = sorted(folder.glob(f"*{suffix}"))
    if len(found) != 1:
        raise SystemExit(f"Expected exactly one {suffix} in {folder}, got {len(found)}")
    return found[0]


def main() -> None:
    if not (BUILD / "index.html").is_file():
        raise SystemExit("Build first with pnpm build:static")
    css_path = one_asset(BUILD / "assets", ".css")
    js_path = one_asset(BUILD / "assets", ".js")
    css = css_path.read_text(encoding="utf-8").replace("</style", "<\\/style")
    js = js_path.read_text(encoding="utf-8").replace("</script", "<\\/script")

    OUT.mkdir(parents=True, exist_ok=True)
    images_out = OUT / "images"
    if images_out.exists():
        shutil.rmtree(images_out)
    shutil.copytree(BUILD / "images", images_out)
    robots = BUILD / "robots.txt"
    if robots.exists():
        shutil.copy2(robots, OUT / "robots.txt")

    html = f'''<!doctype html>
<html lang="zh-Hant">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <base href="./" />
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet" />
    <meta name="theme-color" content="#fff7ec" />
    <meta name="description" content="今天早餐吃哪間？「早知道」是給選擇障礙的政大周邊早餐指南。網站店家資訊為測試資料，可能變動。" />
    <link rel="icon" type="image/webp" href="./images/zaozhidao-mark.webp" />
    <title>早知道｜今天早餐吃哪間？</title>
    <style>\n{css}\n</style>
  </head>
  <body>
    <div id="root"></div>
    <script>window.__MANUS_CONFIG__ = Object.freeze({{}});</script>
    <script>\n{js}\n</script>
  </body>
</html>
'''
    (OUT / "index.html").write_text(html, encoding="utf-8", newline="\n")
    print(f"Packaged: {OUT / 'index.html'} ({len(html.encode('utf-8')):,} bytes)")
    print(f"Local images: {images_out}")


if __name__ == "__main__":
    main()
